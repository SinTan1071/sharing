"""Skeleton for 'nose' module.

Project: nose 1.3 <https://nose.readthedocs.org/>
Skeleton by: Andrey Vlasovskikh <andrey.vlasovskikh@jetbrains.com>
"""
